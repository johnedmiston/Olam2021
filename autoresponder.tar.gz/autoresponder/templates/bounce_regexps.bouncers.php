<br/>
<table cellpadding="0" cellspacing="0" border="0" align="right">
    <tr>
        <td>
            <FORM action="regexps.php" method=POST>
                <input type="hidden" name="action" value="list">
                <input type="submit" name="regexp" value="Regexp Rules >>" alt="Regexp Rules >>">
            </FORM>
        </td>
    </tr>
</table>
<br/>
