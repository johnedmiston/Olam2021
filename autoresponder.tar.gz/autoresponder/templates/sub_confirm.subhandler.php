<br/>
<center><strong>You will need to confirm your subscription.</strong>
    <center><br/>
        <br/>
        An email has been sent to your email address. Follow its instructions.<br/>
        <br/>
