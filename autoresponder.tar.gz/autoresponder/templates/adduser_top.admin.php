<center>
    <br/>
    <FORM action="admin.php" method=POST>
        <table width="750" bgcolor="#3366cc" style="border: 1px solid #000000;">
            <tr>
                <td>
                    <p align="center" style="font-size: 200%"><font color="#FFFFFF">-- Add Subscribers --</font></p>
                </td>
            </tr>
        </table>
        <table width="750" bgcolor="#FFFFFF" style="border: 1px solid #000000;">
            <tr>
                <td>
                    <p align="center" style="font-size: 100%">
                        <font color="#990000">
                            <strong>Warning: </strong>Manually-added subscribers will not receive a confirmation email!
                        </font>
                    </p>
                </td>
            </tr>
        </table>
        <table border="0" width="750" bgcolor="#000066" cellpadding="3" cellspacing="0"
               style="border: 1px solid #000000;">
            <tr>
                <td width="240"><font color="#CCCC33">Email address</font></td>
                <td width="100"><font color="#CCCC33">HTML Email</font></td>
                <td width="275"><font color="#CCCC33">Choose Responder</font></td>
            </tr>
        </table>
        <table border="0" width="750" bgcolor="#CCCCCC" cellspacing="3" cellpadding="0"
               style="border: 1px solid #000000;">
            <tr>
                <td colspan="3"><br/></td>
            </tr>