<br>
<form action="admin.php" method=POST>
    <input type="hidden" name="action" value="Email_Search">
    Search by e-Mail address:
    <input name="email_addy" size=30 maxlength=95 class="fields">
    <input type="submit" name="Search" value="Search">
</form>
