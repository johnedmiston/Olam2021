<?php 
# ------------------------------------------------
# License and copyright:
# See license.txt for license information.
# ------------------------------------------------

# Database information goes here. Server, user, password and database.
$MySQL_server   = 'localhost';
$MySQL_user     = 'infinite';
$MySQL_password = '5tH7w34GlU';
$MySQL_database = 'infinite';

# ------------------------------------------------

# Get the rest of the config auto-magically

/*  mdevine - 09142018 - Commenting out because file doesn't exist 
include("get_config_vars.php");
*/
?>
